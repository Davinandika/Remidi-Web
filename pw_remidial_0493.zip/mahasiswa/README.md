# Mahasiswa
Aplikasi CRUD Mahasiswa berbasis <i>web</i> ini menggunakan Framework Bootstrap-3.3.7, PHP 5.6.24, dan Framework CodeIgniter-3.1.0

Cara menginstall aplikasi ini pada komputer Anda (untuk OS Windows) : 

1. Buat folder baru bernama mahasiswa pada direktori htdocs (di dalam folder XAMPP) 

2. Download dan paste-kan semua file di atas (kecuali mahasiswa.sql) pada folder mahasiswa 

3. Import file mahasiswa.sql ke XAMPP
   Terlebih dahulu buat database di XAMPP dengan nama mahasiswa. Kemudian, import file mahasiswa.sql ke database tersebut.

4. Buka <i>browser</i> Anda (Google, Firefox atau dll) 

5. Ketikkan http://localhost/mahasiswa/ pada <i>browser search bar</i>

6. Tekan Enter dan Anda akan melihat tampilan aplikasi (selesai)

<center> Selamat mencoba </center>
